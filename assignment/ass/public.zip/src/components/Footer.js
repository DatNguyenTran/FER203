function Footer() {
  return (
    <footer>© 2025 MyShop - Contact: https://github.com/DatNguyenTran</footer>
  );
}
export default Footer;
