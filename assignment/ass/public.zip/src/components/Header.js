import { Navbar, Nav, Container, NavDropdown, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import { useContext } from "react";
import CartContext from "../contexts/CartContext";
import AuthContext from "../contexts/AuthContext";

function Header() {
  const { state: cart } = useContext(CartContext);
  const { user, logout } = useContext(AuthContext);

  return (
    <Navbar
      expand="md"
      className="custom-navbar shadow-sm"
      sticky="top"
    >
      <Container>
        <Navbar.Brand
          as={Link}
          to="/"
          className="fw-bold"
        >
          MyShop
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="main-navbar" />
        <Navbar.Collapse id="main-navbar">
          <Nav className="me-auto">
            <Nav.Link
              as={Link}
              to="/wishlist"
              className="nav-link-custom"
            >
              Wishlist
            </Nav.Link>
            <Nav.Link
              as={Link}
              to="/cart"
              className="nav-link-custom"
            >
              Cart ({cart.items.length})
            </Nav.Link>
            <Nav.Link
              as={Link}
              to="/checkout"
              className="nav-link-custom"
            >
              Checkout
            </Nav.Link>
          </Nav>

          {user ? (
            <Nav>
              <NavDropdown
                title={<span className="text-white">{user.username}</span>}
                id="user-menu"
                align="end"
              >
                <NavDropdown.Item
                  as={Link}
                  to="/wishlist"
                >
                  My Wishlist
                </NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item onClick={logout}>Logout</NavDropdown.Item>
              </NavDropdown>
            </Nav>
          ) : (
            <Button
              as={Link}
              to="/login"
              size="sm"
              variant="outline-light"
              className="px-3"
            >
              Sign in
            </Button>
          )}
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Header;
