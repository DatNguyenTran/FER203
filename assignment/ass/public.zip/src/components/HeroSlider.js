import Slider from "react-slick";

function HeroSlider() {
  const settings = {
    dots: true,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 3000,
    pauseOnHover: true,
    arrows: true,
  };
  return (
    <div className="hero-slider">
      <Slider {...settings}>
        <div>
          <img
            src="/images/banner1.jpg"
            alt="Banner 1"
          />
        </div>
        <div>
          <img
            src="/images/banner2.jpg"
            alt="Banner 2"
          />
        </div>
      </Slider>
    </div>
  );
}
export default HeroSlider;
