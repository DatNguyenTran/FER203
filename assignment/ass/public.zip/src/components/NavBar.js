import { Row, Col, Form } from "react-bootstrap";

function NavBar({ search, setSearch, sort, setSort }) {
  return (
    <Row className="my-3">
      <Col md={6}>
        <Form.Control
          type="text"
          placeholder="Search products..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </Col>
      <Col md={3}>
        <Form.Select
          value={sort}
          onChange={(e) => setSort(e.target.value)}
        >
          <option value="">Sort by</option>
          <option value="name">Name A→Z</option>
          <option value="priceAsc">Price Ascending</option>
          <option value="priceDesc">Price Descending</option>
        </Form.Select>
      </Col>
    </Row>
  );
}
export default NavBar;
