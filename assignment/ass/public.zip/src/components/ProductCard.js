import { Card, Button, Badge } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { useContext } from "react";
import CartContext from "../contexts/CartContext";
import WishlistContext from "../contexts/WishlistContext";
import AuthContext from "../contexts/AuthContext";
import { toast } from "react-toastify";

function ProductCard({ product }) {
  const { dispatch: cartDispatch } = useContext(CartContext);
  const { dispatch: wishlistDispatch } = useContext(WishlistContext);
  const { user } = useContext(AuthContext);
  const nav = useNavigate();

  const addCart = () => {
    cartDispatch({ type: "ADD_TO_CART", payload: product });
    toast.success("Added to cart!");
  };

  const addWishlist = () => {
    if (!user) {
      toast.info("Please sign in to save wishlist");
      nav(`/login?redirect_uri=/product/${product.id}`);
      return;
    }
    wishlistDispatch({ type: "ADD_TO_WISHLIST", payload: product });
    toast.success("Added to wishlist!");
  };

  return (
    <Card className="product-card mb-4">
      {/* Badge HOT / SALE */}
      {product.tags.includes("hot") && <Badge className="badge-hot">HOT</Badge>}
      {product.tags.includes("sale") && (
        <Badge className="badge-sale">SALE</Badge>
      )}

      {/* Image */}
      <div className="image-wrapper">
        <Card.Img
          variant="top"
          src={product.image}
          className="product-img"
        />
      </div>

      {/* Content */}
      <Card.Body className="text-center">
        <Card.Title className="product-title">{product.title}</Card.Title>
        {product.tags.includes("sale") ? (
          <Card.Text className="product-price">
            <s>${product.price}</s>{" "}
            <strong className="sale-price">${product.salePrice}</strong>
          </Card.Text>
        ) : (
          <Card.Text className="product-price">${product.price}</Card.Text>
        )}

        {/* Buttons */}
        <div className="d-flex justify-content-center flex-wrap gap-2 mt-3">
          <Button
            variant="primary"
            onClick={addCart}
            className="btn-gradient"
          >
            Add to Cart
          </Button>
          <Button
            variant="outline-danger"
            onClick={addWishlist}
            className="btn-wishlist"
          >
            Wishlist
          </Button>
          <Button
            as={Link}
            to={`/product/${product.id}`}
            variant="secondary"
            className="btn-view"
          >
            View
          </Button>
        </div>
      </Card.Body>
    </Card>
  );
}

export default ProductCard;
