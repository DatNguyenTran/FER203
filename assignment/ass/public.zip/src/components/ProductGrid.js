import { useState, useEffect, useMemo } from "react";
import ProductCard from "./ProductCard";

function ProductGrid({ search, sort }) {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/products")
      .then((res) => res.json())
      .then((data) => setProducts(data));
  }, []);

  const visibleProducts = useMemo(() => {
    let filtered = products.filter((p) =>
      p.title.toLowerCase().includes(search.toLowerCase())
    );

    if (sort === "name") {
      filtered = [...filtered].sort((a, b) => a.title.localeCompare(b.title));
    } else if (sort === "priceAsc") {
      filtered = [...filtered].sort(
        (a, b) => (a.salePrice || a.price) - (b.salePrice || b.price)
      );
    } else if (sort === "priceDesc") {
      filtered = [...filtered].sort(
        (a, b) => (b.salePrice || b.price) - (a.salePrice || a.price)
      );
    }

    return filtered;
  }, [products, search, sort]);

  return (
    <div className="grid">
      {visibleProducts.map((p) => (
        <ProductCard
          key={p.id}
          product={p}
        />
      ))}
    </div>
  );
}
export default ProductGrid;
