import { createContext, useState } from "react";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [redirectAfterLogin, setRedirectAfterLogin] = useState("/");

  const login = async (email, password) => {
    const res = await fetch("http://localhost:5000/accounts");
    const accounts = await res.json();
    const acc = accounts.find(
      (u) => u.email === email && u.password === password
    );
    if (acc) {
      setUser(acc);
      return true;
    }
    return false;
  };

  const register = async (data) => {
    const res = await fetch("http://localhost:5000/accounts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const acc = await res.json();
    setUser(acc);
  };

  const logout = () => setUser(null);

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        register,
        logout,
        redirectAfterLogin,
        setRedirectAfterLogin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
export default AuthContext;
