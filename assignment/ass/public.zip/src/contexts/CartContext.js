import { createContext, useReducer } from "react";

const CartContext = createContext();

function reducer(state, action) {
  switch (action.type) {
    case "ADD_TO_CART":
      const exist = state.items.find((i) => i.id === action.payload.id);
      if (exist) {
        return {
          items: state.items.map((i) =>
            i.id === exist.id ? { ...i, qty: i.qty + 1 } : i
          ),
        };
      }
      return { items: [...state.items, { ...action.payload, qty: 1 }] };
    case "INC_QTY":
      return {
        items: state.items.map((i) =>
          i.id === action.id ? { ...i, qty: i.qty + 1 } : i
        ),
      };
    case "DEC_QTY":
      return {
        items: state.items.map((i) =>
          i.id === action.id && i.qty > 1 ? { ...i, qty: i.qty - 1 } : i
        ),
      };
    case "REMOVE_FROM_CART":
      return { items: state.items.filter((i) => i.id !== action.id) };
    case "CLEAR_CART":
      return { items: [] };
    default:
      return state;
  }
}

export function CartProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, { items: [] });

  return (
    <CartContext.Provider value={{ state, dispatch }}>
      {children}
    </CartContext.Provider>
  );
}
export default CartContext;
