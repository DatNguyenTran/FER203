import { createContext, useReducer } from "react";

const WishlistContext = createContext();

function reducer(state, action) {
  switch (action.type) {
    case "ADD_TO_WISHLIST":
      return { items: [...state.items, action.payload] };
    case "REMOVE_FROM_WISHLIST":
      return { items: state.items.filter((i) => i.id !== action.id) };
    default:
      return state;
  }
}

export function WishlistProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, { items: [] });

  return (
    <WishlistContext.Provider value={{ state, dispatch }}>
      {children}
    </WishlistContext.Provider>
  );
}
export default WishlistContext;
