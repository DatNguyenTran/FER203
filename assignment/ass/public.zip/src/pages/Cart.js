import { useContext } from "react";
import { Table, Button, Container } from "react-bootstrap";
import CartContext from "../contexts/CartContext";
import { Link } from "react-router-dom";

function Cart() {
  const { state, dispatch } = useContext(CartContext);

  const subtotal = state.items.reduce(
    (s, i) => s + (i.salePrice || i.price) * i.qty,
    0
  );

  return (
    <Container className="my-5">
      <h2>Shopping Cart</h2>
      {state.items.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          <Table
            striped
            bordered
            hover
          >
            <thead>
              <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Qty</th>
                <th>Total</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {state.items.map((p) => (
                <tr key={p.id}>
                  <td>{p.title}</td>
                  <td>${p.salePrice || p.price}</td>
                  <td>
                    <Button
                      size="sm"
                      variant="outline-secondary"
                      onClick={() => dispatch({ type: "DEC_QTY", id: p.id })}
                    >
                      -
                    </Button>
                    <span className="mx-2">{p.qty}</span>
                    <Button
                      size="sm"
                      variant="outline-secondary"
                      onClick={() => dispatch({ type: "INC_QTY", id: p.id })}
                    >
                      +
                    </Button>
                  </td>
                  <td>${(p.salePrice || p.price) * p.qty}</td>
                  <td>
                    <Button
                      size="sm"
                      variant="danger"
                      onClick={() =>
                        dispatch({ type: "REMOVE_FROM_CART", id: p.id })
                      }
                    >
                      Remove
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
          <h4>Subtotal: ${subtotal}</h4>
          <Button
            as={Link}
            to="/checkout"
            variant="success"
          >
            Proceed to Checkout
          </Button>
        </>
      )}
    </Container>
  );
}
export default Cart;
