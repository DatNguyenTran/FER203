import { useContext } from "react";
import { Table, Button, Container } from "react-bootstrap";
import CartContext from "../contexts/CartContext";
import AuthContext from "../contexts/AuthContext";
import { toast } from "react-toastify";

function Checkout() {
  const { state, dispatch } = useContext(CartContext);
  const { user } = useContext(AuthContext);

  const total = state.items.reduce(
    (s, i) => s + (i.salePrice || i.price) * i.qty,
    0
  );

  const placeOrder = async () => {
    if (!user) {
      toast.error("You must sign in to place order!");
      return;
    }
    const order = {
      userid: user.id,
      items: state.items,
      total,
      date: new Date().toISOString(),
    };
    await fetch("http://localhost:5000/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(order),
    });
    dispatch({ type: "CLEAR_CART" });
    toast.success("Order placed successfully!");
  };

  return (
    <Container className="my-5">
      <h2>Checkout</h2>
      {state.items.length === 0 ? (
        <p>No items to checkout.</p>
      ) : (
        <>
          <Table
            striped
            bordered
            hover
          >
            <thead>
              <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Qty</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {state.items.map((p) => (
                <tr key={p.id}>
                  <td>{p.title}</td>
                  <td>${p.salePrice || p.price}</td>
                  <td>{p.qty}</td>
                  <td>${(p.salePrice || p.price) * p.qty}</td>
                </tr>
              ))}
            </tbody>
          </Table>
          <h4>Grand Total: ${total}</h4>
          <Button
            variant="primary"
            onClick={placeOrder}
          >
            Place Order
          </Button>
        </>
      )}
    </Container>
  );
}
export default Checkout;
