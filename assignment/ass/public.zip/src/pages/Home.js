import HeroSlider from "../components/HeroSlider";
import NavBar from "../components/NavBar";
import ProductGrid from "../components/ProductGrid";
import { useState } from "react";

function Home() {
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("");

  return (
    <div>
      <HeroSlider />
      <NavBar
        search={search}
        setSearch={setSearch}
        sort={sort}
        setSort={setSort}
      />
      <ProductGrid
        search={search}
        sort={sort}
      />
    </div>
  );
}
export default Home;
