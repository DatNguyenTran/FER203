import { useState, useContext } from "react";
import { Form, Button, Container, Row, Col, Card } from "react-bootstrap";
import AuthContext from "../contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function Login() {
  const [email, setEmail] = useState("");
  const [pwd, setPwd] = useState("");
  const { login } = useContext(AuthContext);
  const nav = useNavigate();

  const handleLogin = async () => {
    if (await login(email, pwd)) {
      toast.success("Login success!");
      nav("/");
    } else {
      toast.error("Invalid credentials!");
    }
  };

  return (
    <Container className="my-5">
      <Row className="justify-content-center">
        <Col md={6}>
          <Card>
            <Card.Body>
              <h3 className="mb-3">Sign In</h3>
              <Form>
                <Form.Group className="mb-3">
                  <Form.Label>Email</Form.Label>
                  <Form.Control
                    type="email"
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Password</Form.Label>
                  <Form.Control
                    type="password"
                    onChange={(e) => setPwd(e.target.value)}
                  />
                </Form.Group>
                <Button
                  onClick={handleLogin}
                  variant="primary"
                >
                  Login
                </Button>
              </Form>
              <div className="mt-3">
                New Customer?{" "}
                <Button
                  variant="link"
                  onClick={() => nav("/register")}
                >
                  Create an account
                </Button>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}
export default Login;
