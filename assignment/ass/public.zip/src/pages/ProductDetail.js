import { useParams } from "react-router-dom";
import { useEffect, useState, useContext } from "react";
import { Card, Button, Container } from "react-bootstrap";
import CartContext from "../contexts/CartContext";
import WishlistContext from "../contexts/WishlistContext";
import AuthContext from "../contexts/AuthContext";
import { toast } from "react-toastify";

function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const { dispatch: cartDispatch } = useContext(CartContext);
  const { dispatch: wishlistDispatch } = useContext(WishlistContext);
  const { user } = useContext(AuthContext);

  useEffect(() => {
    fetch(`http://localhost:5000/products/${id}`)
      .then((res) => res.json())
      .then((data) => setProduct(data));
  }, [id]);

  if (!product) return <p>Loading...</p>;

  const addCart = () => {
    cartDispatch({ type: "ADD_TO_CART", payload: product });
    toast.success("Added to cart!");
  };

  const addWishlist = () => {
    if (!user) {
      toast.info("Please sign in to save wishlist");
      return;
    }
    wishlistDispatch({ type: "ADD_TO_WISHLIST", payload: product });
    toast.success("Added to wishlist!");
  };

  return (
    <Container className="my-5">
      <Card>
        <Card.Img
          variant="top"
          src={product.image}
          style={{ maxWidth: 400 }}
        />
        <Card.Body>
          <Card.Title>{product.title}</Card.Title>
          <Card.Text>{product.description}</Card.Text>
          {product.tags.includes("sale") ? (
            <p>
              <s>${product.price}</s> <strong>${product.salePrice}</strong>
            </p>
          ) : (
            <p>${product.price}</p>
          )}
          <Button
            variant="primary"
            className="me-2"
            onClick={addCart}
          >
            Add to Cart
          </Button>
          <Button
            variant="outline-danger"
            onClick={addWishlist}
          >
            Add to Wishlist
          </Button>
        </Card.Body>
      </Card>
    </Container>
  );
}
export default ProductDetail;
