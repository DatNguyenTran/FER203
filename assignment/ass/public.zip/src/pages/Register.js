import { useState, useContext } from "react";
import {
  Form,
  Button,
  Container,
  Row,
  Col,
  Card,
  ProgressBar,
} from "react-bootstrap";
import AuthContext from "../contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function Register() {
  const { register } = useContext(AuthContext);
  const nav = useNavigate();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    name: "",
    email: "",
    avatar: "",
    username: "",
    password: "",
    confirm: "",
    secretQuestion: "",
    answer: "",
  });

  const next = () => setStep(step + 1);
  const prev = () => setStep(step - 1);

  const handleSubmit = async () => {
    if (form.password !== form.confirm) {
      toast.error("Passwords do not match!");
      return;
    }
    await register({
      username: form.username,
      email: form.email,
      password: form.password,
      secretQuestion: form.secretQuestion,
      answer: form.answer,
      wishlist: [],
    });
    toast.success("Registration successful. You are now signed in.");
    nav("/");
  };

  return (
    <Container className="my-5">
      <Row className="justify-content-center">
        <Col md={6}>
          <Card>
            <Card.Body>
              <ProgressBar
                now={(step / 2) * 100}
                className="mb-3"
              />
              {step === 1 && (
                <>
                  <Form.Group className="mb-3">
                    <Form.Label>Full Name</Form.Label>
                    <Form.Control
                      value={form.name}
                      onChange={(e) =>
                        setForm({ ...form, name: e.target.value })
                      }
                    />
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>Email</Form.Label>
                    <Form.Control
                      type="email"
                      value={form.email}
                      onChange={(e) =>
                        setForm({ ...form, email: e.target.value })
                      }
                    />
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>Avatar</Form.Label>
                    <Form.Control
                      type="file"
                      onChange={(e) =>
                        setForm({
                          ...form,
                          avatar: URL.createObjectURL(e.target.files[0]),
                        })
                      }
                    />
                  </Form.Group>
                  {form.avatar && (
                    <img
                      src={form.avatar}
                      alt="avatar"
                      width={100}
                      className="mb-3"
                    />
                  )}
                  <Button onClick={next}>Next</Button>
                </>
              )}
              {step === 2 && (
                <>
                  <Form.Group className="mb-3">
                    <Form.Label>Username</Form.Label>
                    <Form.Control
                      onChange={(e) =>
                        setForm({ ...form, username: e.target.value })
                      }
                    />
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>Password</Form.Label>
                    <Form.Control
                      type="password"
                      onChange={(e) =>
                        setForm({ ...form, password: e.target.value })
                      }
                    />
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>Confirm Password</Form.Label>
                    <Form.Control
                      type="password"
                      onChange={(e) =>
                        setForm({ ...form, confirm: e.target.value })
                      }
                    />
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>Secret Question</Form.Label>
                    <Form.Select
                      onChange={(e) =>
                        setForm({ ...form, secretQuestion: e.target.value })
                      }
                    >
                      <option>Choose question</option>
                      <option>Your first pet?</option>
                      <option>Favorite color?</option>
                    </Form.Select>
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>Answer</Form.Label>
                    <Form.Control
                      onChange={(e) =>
                        setForm({ ...form, answer: e.target.value })
                      }
                    />
                  </Form.Group>
                  <Button
                    variant="secondary"
                    className="me-2"
                    onClick={prev}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="primary"
                    onClick={handleSubmit}
                  >
                    Submit
                  </Button>
                </>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}
export default Register;
