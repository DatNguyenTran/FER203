import { useContext } from "react";
import { ListGroup, Container } from "react-bootstrap";
import WishlistContext from "../contexts/WishlistContext";

function Wishlist() {
  const { state } = useContext(WishlistContext);

  return (
    <Container className="my-5">
      <h2>Wishlist</h2>
      {state.items.length === 0 ? (
        <p>No items in wishlist.</p>
      ) : (
        <ListGroup>
          {state.items.map((p) => (
            <ListGroup.Item key={p.id}>{p.title}</ListGroup.Item>
          ))}
        </ListGroup>
      )}
    </Container>
  );
}
export default Wishlist;
